import { IsSponsorPipe } from './is-sponsor.pipe';

describe('IsSponsorPipe', () => {
  it('create an instance', () => {
    const pipe = new IsSponsorPipe();
    expect(pipe).toBeTruthy();
  });
});
