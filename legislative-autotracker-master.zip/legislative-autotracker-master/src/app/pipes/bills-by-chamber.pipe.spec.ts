import { BillsByChamberPipe } from './bills-by-chamber.pipe';

describe('BillsByChamberPipe', () => {
  it('create an instance', () => {
    const pipe = new BillsByChamberPipe();
    expect(pipe).toBeTruthy();
  });
});
