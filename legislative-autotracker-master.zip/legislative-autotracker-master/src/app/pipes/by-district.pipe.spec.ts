import { ByDistrictPipe } from './by-district.pipe';

describe('ByDistrictPipe', () => {
  it('create an instance', () => {
    const pipe = new ByDistrictPipe();
    expect(pipe).toBeTruthy();
  });
});
