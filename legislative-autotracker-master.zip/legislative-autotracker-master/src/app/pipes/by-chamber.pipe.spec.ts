import { ByChamberPipe } from './by-chamber.pipe';

describe('ByChamberPipe', () => {
  it('create an instance', () => {
    const pipe = new ByChamberPipe();
    expect(pipe).toBeTruthy();
  });
});
