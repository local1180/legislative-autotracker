import { Address } from "../interfaces/address";

export class User {
	address: Address;
}
