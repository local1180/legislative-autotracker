export interface CivicInfoDivisionsResponse {
	divisions: {}
}
