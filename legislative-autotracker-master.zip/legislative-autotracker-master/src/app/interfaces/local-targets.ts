export interface LocalTargets {
	"gsx$district": { "$t": number },
	"gsx$local": { "$t": number },
}
