export interface PriorityBill {
	"category": [];
	"content": {
		"type": string;
		"$t": string;
	};
	"gsx$assemblynum": {"$t": string;};
	"gsx$billname": {"$t": string;};
	"gsx$senatenum": {"$t": string;};
	"gsx$sessionyear": {"$t": string;};
	"id": {"$t": string;};
	"link": [];
	"title": {
		"type": string;
		"$t": string;
	};
	updated: {
		$t: string;
	}
}
