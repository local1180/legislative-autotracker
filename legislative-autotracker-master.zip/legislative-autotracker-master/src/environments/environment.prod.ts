export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyAo496JJcYoPU0UhnZjxWTQ7v60oO64Atw',
    authDomain: 'lpatapp-rc4.firebaseapp.com',
    databaseURL: 'https://lpatapp-rc4.firebaseio.com',
    projectId: 'lpatapp-rc4',
    storageBucket: 'lpatapp-rc4.appspot.com',
    messagingSenderId: '209180008028'
  }
};
